package com.app.shoutbox.dao;

public interface FriendDao {

	public String sendFriendReq(int user_id_sender , int user_id_recevier); 
}
