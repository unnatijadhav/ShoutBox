package com.app.shoutbox.dao;

import com.app.shoutbox.model.User;

public interface UserDao {

	public User registerUser(User u); 
}
