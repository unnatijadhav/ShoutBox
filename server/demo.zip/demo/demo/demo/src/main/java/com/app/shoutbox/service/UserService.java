package com.app.shoutbox.service;

import java.util.List;

import com.app.shoutbox.model.User;

public interface UserService {
	public User registerUser(User u);
}
