package com.app.shoutbox.model;

public enum FriendRequestFlag {
	REJECTED,APPROVED,PENDING,SENT
}
