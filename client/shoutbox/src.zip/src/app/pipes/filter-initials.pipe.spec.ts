import { FilterInitialsPipe } from './filter-initials.pipe';

describe('FilterInitialsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterInitialsPipe();
    expect(pipe).toBeTruthy();
  });
});
