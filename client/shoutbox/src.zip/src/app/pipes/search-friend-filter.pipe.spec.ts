import { SearchFriendFilterPipe } from './search-friend-filter.pipe';

describe('SearchFriendFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchFriendFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
