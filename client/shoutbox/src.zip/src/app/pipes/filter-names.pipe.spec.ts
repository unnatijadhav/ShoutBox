import { FilterNamesPipe } from './filter-names.pipe';

describe('FilterNamesPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterNamesPipe();
    expect(pipe).toBeTruthy();
  });
});
