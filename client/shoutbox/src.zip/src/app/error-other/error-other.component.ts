import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-other',
  templateUrl: './error-other.component.html',
  styleUrls: ['./error-other.component.scss']
})
export class ErrorOtherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
