import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-write-comment',
  templateUrl: './write-comment.component.html',
  styleUrls: ['./write-comment.component.scss']
})
export class WriteCommentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
